#' @keywords internal
#'
rename_by_idx = function (data, idx, into){
  names(data)[idx] = into
  return(data)
}
