#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom magrittr %<>%
#' @importFrom magrittr %>%
#' @importFrom rlang .data
## usethis namespace: end
NULL
